library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_arith.all;
use ieee.std_logic_unsigned.all;

entity pc is
port (clr, clk, ld, inc : in std_logic;
		d : in std_logic_vector(31 downto 0);
		Q : out std_logic_vector(31 downto 0)
		);
end pc;
--starts on postive edge of the flip flop
--enable turns on

--enable still on in the middle so stays 1 until enable = 0 or reset = 1
architecture Behavior of pc is
--list of all components used in the Program Counter
-- **change increment and load signals**

component add
port (A: in std_logic_vector(31 downto 0);
		B: out std_logic_vector(31 downto 0)
		);
end component;

--multiplexer
component mux2to1
port (s : std_logic;
w0, w1 : in std_logic_vector(31 downto 0);
f : out std_logic_vector(31 downto 0)
);
end component;

--32bit register
component register32
port(ld, clr, clk : in std_logic;
d : in std_logic_vector(31 downto 0);
Q : out std_logic_vector(31 downto 0)
);
end component;

signal add_out : std_logic_vector(31 downto 0);
signal mux_out : std_logic_vector(31 downto 0);
signal q_out   : std_logic_vector(31 downto 0);

begin
	add0: add port map(q_out, add_out);
	mux0: mux2to1 port map(inc, d, add_out, mux_out);
	reg0: register32 port map(ld, clr, clk, mux_out, q_out);
	q<= q_out;
end Behavior;